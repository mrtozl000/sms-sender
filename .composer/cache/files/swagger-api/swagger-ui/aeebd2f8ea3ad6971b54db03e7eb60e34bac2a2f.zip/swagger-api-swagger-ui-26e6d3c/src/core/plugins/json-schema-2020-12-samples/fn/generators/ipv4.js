/**
 * @prettier
 */
const ipv4Generator = () => "198.51.100.42"

export default ipv4Generator
